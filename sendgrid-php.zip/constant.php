<?php
	define('SECRET_KEY','INSERT_SECRET_KEY');
?>
